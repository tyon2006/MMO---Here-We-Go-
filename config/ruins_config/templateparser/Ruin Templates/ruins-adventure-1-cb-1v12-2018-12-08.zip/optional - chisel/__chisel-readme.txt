CHISEL FOLDERS:
This is an assortment of structures using Chisel blocks.  There may also be some that use blocks from other mods, but I've "hidden" those in biome folders associated with those mods.  If you're not using those mods, you can leave these folders out.

In particular:
* bamboo_forest: Biomes o' Plenty

